/*************************************************************************
  This code is from Dynamic Web Coding at www.dyn-web.com
  Copyright 2001-4 by Sharon Paine 
  See Terms of Use at www.dyn-web.com/bus/terms.html
  regarding conditions under which you may use this code.
  This notice must be retained in the code as is!
*************************************************************************/
function initScrollLayer(){var r=new dw_scrollObj("wn","lyr1");r.setUpScrollbar("dragBar","track","v",1,1),dw_scrollObj.GeckoTableBugFix("wn")}